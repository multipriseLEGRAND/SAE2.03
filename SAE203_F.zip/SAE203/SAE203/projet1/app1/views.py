from django.shortcuts import render, get_object_or_404, redirect, HttpResponse, HttpResponseRedirect
from django.views.decorators.http import require_POST
from django.core.exceptions import ObjectDoesNotExist
from . import models
from .models import Clients, Produits, CategoriesDeProduit, Commandes
from .forms import (
    ClientForm, ProduitForm,
    CommandeForm, DetailCommandeFormSet,
    CategorieProduitForm
)


def index_accueil(request):
    produits = Produits.objects.all()
    return render(request, "app1/index.html")

def client_formulaire(request):
    form = ClientForm()
    return render(request, "app1/Clients/Client_Ajout.html", {"formulaire": form})
def client_traitement(request):
    form = ClientForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect("client_afficher_all")
    return render(request, "app1/Clients/Client_Ajout.html", {"formulaire": form})


def client_afficher_all(request):
    liste_data = Clients.objects.all()
    return render(request, "app1/Clients/Client_Liste.html", {"liste": liste_data})

def client_modifier(request, id):
    data = get_object_or_404(Clients, pk=id)
    form = ClientForm(instance=data)
    return render(request, "app1/Clients/Client_Ajout.html", {"formulaire": form, "id": id})

def client_menu(request):
    return render(request, "app1/Clients/Client_Menu.html")

def client_sauvegarder_modif(request, id):
    data = get_object_or_404(Clients, pk=id)
    form = ClientForm(request.POST, instance=data)
    if form.is_valid():
        form.save()
        return redirect("client_afficher_all")
    return render(request, "app1/Clients/Client_Ajout.html", {"formulaire": form, "id": id})

def client_supprimer(request, id):
    data = get_object_or_404(Clients, pk=id)
    data.delete()
    return redirect("client_afficher_all")


def produit_ajout(request):
    if request.method == "POST":
        form = ProduitForm(request.POST, request.FILES)
        if form.is_valid():
            article = form.save()
            return render(request, "app1/Produits/Produit_Affiche.html", {"article": article})
    else:
        form = ProduitForm()
    return render(request, "app1/Produits/Produit_Ajout.html", {"form": form})

def produit_all(request):
    articlevue = Produits.objects.all()
    return render(request, "app1/Produits/Produit_All.html", {"articlevue": articlevue})

def produit_affiche(request, id):
    articleread = get_object_or_404(Produits, pk=id)
    return render(request, "app1/Produits/Produit_Affiche.html", {"article": articleread})

def produit_supprimer(request, id):
    article = get_object_or_404(Produits, pk=id)
    article.delete()
    return redirect("produit_all")

def produit_modifier(request, id):
    article = get_object_or_404(Produits, pk=id)
    if request.method == "POST":
        form = ProduitForm(request.POST, request.FILES, instance=article)
        if form.is_valid():
            form.save()
            return redirect("produit_all")
    else:
        form = ProduitForm(instance=article)
    return render(request, "app1/Produits/Produit_Ajout.html", {"form": form})



def categorie_formulaire(request):
    form = CategorieProduitForm()
    return render(request, "app1/Categories/Categorie_Form.html", {"formulaire": form})

def categorie_traitement(request):
    form = CategorieProduitForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect("categorie_afficher_all")
    return render(request, "app1/Categories/Categorie_Form.html", {"formulaire": form})


def categorie_afficher_all(request):
    liste = CategoriesDeProduit.objects.all()
    return render(request, "app1/Categories/Categorie_Afficher_All.html", {"liste": liste})

def categorie_modifier(request, id):
    data = get_object_or_404(CategoriesDeProduit, pk=id)
    form = CategorieProduitForm(instance=data)
    return render(request, "app1/Categories/Categorie_Form.html", {"formulaire": form, "id": id})

def categorie_sauvegarder_modif(request, id):
    data = get_object_or_404(CategoriesDeProduit, pk=id)
    form = CategorieProduitForm(request.POST, instance=data)
    if form.is_valid():
        form.save()
        return redirect("categorie_afficher_all")
    return render(request, "app1/Categories/Categorie_Form.html", {"formulaire": form, "id": id})

def categorie_supprimer(request, id):
    data = get_object_or_404(CategoriesDeProduit, pk=id)
    data.delete()
    return redirect("categorie_afficher_all")


def liste_commandes(request):
    commandes = Commandes.objects.select_related('client').all()
    return render(request, 'app1/Commandes/Commande_Liste.html', {'commandes': commandes})

def nouvelle_commande(request):
    if request.method == 'POST':
        form = CommandeForm(request.POST)
        formset = DetailCommandeFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            commande = form.save()
            formset.instance = commande
            formset.save()
            return redirect('commande_detail', pk=commande.pk)
    else:
        form = CommandeForm()
        formset = DetailCommandeFormSet()

    return render(request, 'app1/Commandes/Commande_Form.html', {
        'form': form,
        'formset': formset,
        'commande': None,
    })

def modifier_commande(request, pk):
    commande = get_object_or_404(Commandes, pk=pk)
    if request.method == 'POST':
        form = CommandeForm(request.POST, instance=commande)
        formset = DetailCommandeFormSet(request.POST, instance=commande)
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            return redirect('commande_detail', pk=commande.pk)
    else:
        form = CommandeForm(instance=commande)
        formset = DetailCommandeFormSet(instance=commande)
    return render(request, 'app1/Commandes/Commande_Form.html', {
        'form': form, 'formset': formset, 'commande': commande
    })

def supprimer_commande(request, pk):
    commande = get_object_or_404(Commandes, pk=pk)
    if request.method == 'POST':
        commande.delete()
        return redirect('commande_list')
    return render(request, 'app1/Commandes/Commande_Confirm_Delete.html', {'commande': commande})

def detail_commande(request, pk):
    commande = get_object_or_404(Commandes, pk=pk)
    return render(request, 'app1/Commandes/Commande_Detail.html', {'commande': commande})
