from django.db import models
from django.utils import timezone

class Clients(models.Model):
    num_client = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=45, null=True, blank=True)
    prenom = models.CharField(max_length=45, null=True, blank=True)
    date_inscription = models.DateField(default=timezone.now, null=True, blank=True)
    adresse = models.CharField(max_length=45, null=True, blank=True)
    email = models.CharField(max_length=45, null=True, blank=True)

    def __str__(self):
        return f"{self.prenom} {self.nom}"



class CategoriesDeProduit(models.Model):
    idcategories = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=45, null=False, blank=False)
    descriptif = models.CharField(max_length=45, null=True, blank=True)

    def __str__(self):
        return self.nom


class Produits(models.Model):
    idproduits = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=45, null=True, blank=True)
    date_peremption = models.CharField(max_length=45, null=True, blank=True)
    photo = models.ImageField(upload_to='produits/', null=True, blank=True)
    marque = models.CharField(max_length=45, null=True, blank=True)
    prix = models.DecimalField(max_digits=6, decimal_places=2)
    categorie = models.ForeignKey(
        CategoriesDeProduit,
        on_delete=models.CASCADE
    )

    def __str__(self):
        return self.nom


class Commandes(models.Model):
    num_commande = models.AutoField(primary_key=True)
    client = models.ForeignKey(
        Clients,
        on_delete=models.CASCADE
    )
    date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"Commande #{self.num_commande}"


class DetailCommande(models.Model):
    iddetail_commande = models.AutoField(primary_key=True)
    commande = models.ForeignKey(
        Commandes,
        on_delete=models.CASCADE
    )
    produit = models.ForeignKey(
        Produits,
        on_delete=models.CASCADE
    )
    quantite = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return f"{self.produit.nom} x{self.quantite} (Commande #{self.commande.num_commande})"
