from django.urls import path
from . import views

urlpatterns = [

    path("", views.index_accueil, name="accueil"),

    path("ROUTE_formulaire/", views.client_formulaire, name="client_formulaire"),
    path("ROUTE_traitement/", views.client_traitement, name="client_traitement"),
    path("ROUTE_afficher_all/", views.client_afficher_all, name="client_afficher_all"),
    path("ROUTE_modifier/<int:id>/", views.client_modifier, name="client_modifier"),
    path("ROUTE_sauvegarder_modif/<int:id>/", views.client_sauvegarder_modif, name="client_sauvegarder_modif"),
    path("ROUTE_supprimer/<int:id>/", views.client_supprimer, name="client_supprimer"),
    path("ROUTE_clients_menu/", views.client_menu, name="client_menu"),


    path("produits/ajout/", views.produit_ajout, name="produit_ajout"),
    path("produits/", views.produit_all, name="produit_all"),
    path("produits/<int:id>/", views.produit_affiche, name="produit_affiche"),
    path("produits/<int:id>/modifier/", views.produit_modifier, name="produit_modifier"),
    path("produits/<int:id>/supprimer/", views.produit_supprimer, name="produit_supprimer"),

    path("commandes/", views.liste_commandes, name="commande_list"),
    path("commandes/nouvelle/", views.nouvelle_commande, name="commande_nouvelle"),
    path("commandes/<int:pk>/modifier/", views.modifier_commande, name="commande_modifier"),
    path("commandes/<int:pk>/supprimer/", views.supprimer_commande, name="commande_supprimer"),
    path("commandes/<int:pk>/", views.detail_commande, name="commande_detail"),

    path("categories/formulaire/", views.categorie_formulaire, name="categorie_formulaire"),
    path("categories/traitement/", views.categorie_traitement, name="categorie_traitement"),
    path("categories/", views.categorie_afficher_all, name="categorie_afficher_all"),
    path("categories/<int:id>/modifier/", views.categorie_modifier, name="categorie_modifier"),
    path("categories/<int:id>/sauvegarder/", views.categorie_sauvegarder_modif, name="categorie_sauvegarder_modif"),
    path("categories/<int:id>/supprimer/", views.categorie_supprimer, name="categorie_supprimer"),
]
