from django.forms import ModelForm, inlineformset_factory
from django.utils.translation import gettext_lazy as _
from django import forms
from . import models
from .models import Clients, Commandes, DetailCommande


class ClientForm(ModelForm):
    class Meta:
        model = models.Clients
        fields = '__all__'
        labels = {
            'nom': _('Nom'),
            'prenom': _('Prénom'),
            'date_inscription': _('Date d’inscription'),
            'adresse': _('Adresse'),
            'email': _('Email'),
        }
        widgets = {
            'date_inscription': forms.DateInput(attrs={'type': 'date'}),
        }


class CategorieProduitForm(ModelForm):
    class Meta:
        model = models.CategoriesDeProduit
        fields = '__all__'
        labels = {
            'nom': _('Nom de la catégorie'),
            'descriptif': _('Descriptif'),
        }


class ProduitForm(ModelForm):
    class Meta:
        model = models.Produits
        fields = '__all__'
        labels = {
            'nom': _('Nom du produit'),
            'date_peremption': _('Date de péremption'),
            'photo': _('Image du produit'),
            'marque': _('Marque'),
            'prix': _('Prix'),
            'categorie': _('Catégorie'),
        }



class CommandeForm(ModelForm):
    class Meta:
        model = models.Commandes
        fields = ['client', 'date']
        labels = {
            'client': _('Client'),
            'date': _('Date de la commande'),
        }
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }


class DetailCommandeForm(ModelForm):
    class Meta:
        model = models.DetailCommande
        fields = '__all__'
        labels = {
            'commande': _('Commande'),
            'produit': _('Produit'),
            'quantite': _('Quantité'),
        }


DetailCommandeFormSet = inlineformset_factory(
    Commandes, DetailCommande,
    fields=('produit', 'quantite'),
    extra=1, can_delete=True
)
